import pandas as pd 
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from datetime import datetime, timedelta
import logging
import os
from typing import List, Dict, Optional, Tuple
import json
import aiohttp
import requests
from fastapi import FastAPI, WebSocket, HTTPException, Form, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from contextlib import asynccontextmanager
import asyncio
import sys
if sys.platform.startswith('win'):
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.FileHandler('memecoin_monitor.log'), logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

# Global variable for the monitor instance
monitor = None

# Lifespan context manager (replacing on_event)
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    global monitor
    monitor = MemecoinMonitor()
    yield
    # Shutdown
    # Add any cleanup code here if needed

app = FastAPI(title="Memecoin Monitor", lifespan=lifespan)

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Setup templates
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")

class MemecoinMonitor:
    def __init__(self):
        # Initialize API endpoints and keys
        self.twitter_api_url = "https://twitter154.p.rapidapi.com/user/tweets"
        self.grok_api_url = "https://grokai.p.rapidapi.com/analyze"
        self.solscan_api_url = "https://public-api.solscan.io/chaininfo"
        self.rugcheck_api_url = "https://api.rugcheck.xyz/v1"
        
        self.rapid_api_key = "6f36e9916dmsh75e673285c2f7f9p195b33jsn2a3a70e07bff"
        self.solscan_api_key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjcmVhdGVkQXQiOjE3Mzc1MjgyMTI0MTQsImVtYWlsIjoiamlyb24wOTIxQGdtYWlsLmNvbSIsImFjdGlvbiI6InRva2VuLWFwaSIsImFwaVZlcnNpb24iOiJ2MiIsImlhdCI6MTczNzUyODIxMn0.fUqcaOeNQzWW4SV6-HrZC8nQNRCHdrGUr59m1xxVx88"
        
        # Initialize ML components
        self.active_connections = set()
        self.scaler = StandardScaler()  # Initialize scaler here
        self._initialize_ml_model()  # Initialize model
        
    def _initialize_ml_model(self):
        """Initialize and train the ML model with dummy data"""
        try:
            # Create synthetic training data
            np.random.seed(42)  # For reproducibility
            n_samples = 1000
            n_features = 5
            
            # Generate synthetic features
            X = np.random.randn(n_samples, n_features)
            # Generate synthetic target (score between 0 and 10)
            y = np.clip(
                5 + 0.5 * X.sum(axis=1) + np.random.randn(n_samples),
                0, 10
            )
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # Fit scaler
            X_train_scaled = self.scaler.fit_transform(X_train)
            
            # Initialize and train model
            self.model = GradientBoostingRegressor(
                n_estimators=100,
                learning_rate=0.1,
                max_depth=3,
                random_state=42
            )
            self.model.fit(X_train_scaled, y_train)
            
            # Log training results
            test_score = self.model.score(self.scaler.transform(X_test), y_test)
            logger.info(f"Model R² score on test set: {test_score:.3f}")
            
        except Exception as e:
            logger.error(f"Error initializing ML model: {str(e)}")
            raise

        
        model = GradientBoostingRegressor(
            n_estimators=100,
            learning_rate=0.1,
            max_depth=3
        )
        model.fit(X_train_scaled, y_train)
        return model

    async def get_twitter_analysis(self, username: str) -> Dict:
        """Get and analyze tweets from a user"""
        headers = {
            "X-RapidAPI-Key": self.rapid_api_key,
            "X-RapidAPI-Host": "twitter154.p.rapidapi.com"
        }
        params = {"username": username, "limit": "20"}
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(self.twitter_api_url, headers=headers, params=params) as response:
                    if response.status == 200:
                        tweets_data = await response.json()
                        return await self._analyze_tweets(tweets_data.get('results', []))
                    else:
                        logger.error(f"Twitter API error: {response.status}")
                        return {"error": "Failed to fetch tweets"}
        except Exception as e:
            logger.error(f"Twitter analysis error: {str(e)}")
            return {"error": str(e)}

    async def _analyze_tweets(self, tweets: List[Dict]) -> Dict:
        """Analyze tweets using Grok AI"""
        headers = {
            "content-type": "application/json",
            "X-RapidAPI-Key": self.rapid_api_key,
            "X-RapidAPI-Host": "grokai.p.rapidapi.com"
        }
        
        analyses = []
        for tweet in tweets:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(
                        self.grok_api_url,
                        headers=headers,
                        json={"text": tweet.get('text', '')}
                    ) as response:
                        if response.status == 200:
                            analysis = await response.json()
                            analyses.append({
                                'tweet': tweet.get('text', ''),
                                'analysis': analysis,
                                'sentiment_score': analysis.get('sentiment', {}).get('score', 0)
                            })
            except Exception as e:
                logger.error(f"Grok analysis error: {str(e)}")
                
        return {
            'analyses': analyses,
            'average_sentiment': np.mean([a['sentiment_score'] for a in analyses if 'sentiment_score' in a])
        }

    async def scan_new_tokens(self) -> List[Dict]:
        """Scan for new token launches"""
        headers = {"Authorization": f"Bearer {self.solscan_api_key}"}
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(self.solscan_api_url, headers=headers) as response:
                    if response.status == 200:
                        tokens = await response.json()
                        return await self._analyze_tokens(tokens)
                    return []
        except Exception as e:
            logger.error(f"Token scanning error: {str(e)}")
            return []

    async def _analyze_tokens(self, tokens: List[Dict]) -> List[Dict]:
        """Analyze tokens and calculate risk scores"""
        analyzed_tokens = []
        
        for token in tokens:
            try:
                # Get rugcheck analysis
                async with aiohttp.ClientSession() as session:
                    async with session.get(
                        f"{self.rugcheck_api_url}/scan/{token['address']}"
                    ) as response:
                        if response.status == 200:
                            risk_data = await response.json()
                            
                            # Calculate comprehensive score
                            features = self._extract_token_features(token, risk_data)
                            scaled_features = self.scaler.transform([features])
                            score = float(self.model.predict(scaled_features)[0])
                            
                            if score >= 5.0:  # Only include tokens with score >= 5
                                analyzed_tokens.append({
                                    'address': token['address'],
                                    'name': token.get('name', 'Unknown'),
                                    'score': score,
                                    'risk_analysis': risk_data,
                                    'timestamp': datetime.now().isoformat()
                                })
            except Exception as e:
                logger.error(f"Token analysis error: {str(e)}")
                
        return sorted(analyzed_tokens, key=lambda x: x['score'], reverse=True)

    def _extract_token_features(self, token: Dict, risk_data: Dict) -> List[float]:
        """Extract numerical features for ML model"""
        # Example feature extraction - modify based on available data
        return [
            float(token.get('total_supply', 0)),
            float(token.get('holder_count', 0)),
            float(risk_data.get('liquidity_score', 0)),
            float(risk_data.get('contract_score', 0)),
            float(risk_data.get('holder_distribution_score', 0))
        ]

    async def broadcast_updates(self, data: Dict):
        """Broadcast updates to all connected clients"""
        for connection in self.active_connections:
            try:
                await connection.send_json(data)
            except Exception as e:
                logger.error(f"Broadcast error: {str(e)}")
                self.active_connections.remove(connection)

# API Routes
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/api/twitter/{username}")
async def analyze_twitter(username: str):
    """Analyze Twitter user's tweets"""
    try:
        analysis = await monitor.get_twitter_analysis(username)
        return JSONResponse(content=analysis)
    except Exception as e:
        logger.error(f"Twitter analysis endpoint error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/scan")
async def scan_tokens():
    """Scan for new tokens"""
    try:
        tokens = await monitor.scan_new_tokens()
        return JSONResponse(content={"tokens": tokens})
    except Exception as e:
        logger.error(f"Token scan endpoint error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    monitor.active_connections.add(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            # Process received data if needed
    except Exception as e:
        logger.error(f"WebSocket error: {str(e)}")
    finally:
        monitor.active_connections.remove(websocket)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)