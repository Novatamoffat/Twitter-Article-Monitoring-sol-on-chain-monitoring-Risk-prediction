// WebSocket connection
let ws = null;
let sentimentChart = null;

// Initialize WebSocket connection
function initWebSocket() {
    ws = new WebSocket(`ws://${window.location.host}/ws`);
    
    ws.onopen = () => {
        showStatus('Connected to server', 'success');
    };

    ws.onclose = () => {
        showStatus('Disconnected from server', 'error');
        // Try to reconnect after 5 seconds
        setTimeout(initWebSocket, 5000);
    };

    ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        updateLiveUpdates(data);
    };

    ws.onerror = (error) => {
        showStatus('WebSocket error occurred', 'error');
        console.error('WebSocket error:', error);
    };
}

// Status message helper
function showStatus(message, type = 'info') {
    const statusDiv = document.getElementById('status-message');
    const messagePara = statusDiv.querySelector('p');
    
    statusDiv.className = 'mb-4';
    switch(type) {
        case 'success':
            statusDiv.querySelector('div').className = 'p-4 rounded-md bg-green-100 text-green-700';
            break;
        case 'error':
            statusDiv.querySelector('div').className = 'p-4 rounded-md bg-red-100 text-red-700';
            break;
        default:
            statusDiv.querySelector('div').className = 'p-4 rounded-md bg-blue-100 text-blue-700';
    }
    
    messagePara.textContent = message;
    statusDiv.classList.remove('hidden');

    // Hide after 5 seconds
    setTimeout(() => {
        statusDiv.classList.add('hidden');
    }, 5000);
}

// Twitter analysis
async function analyzeTwitterUser() {
    const username = document.getElementById('twitter-username').value;
    if (!username) {
        showStatus('Please enter a Twitter username', 'error');
        return;
    }

    try {
        showStatus('Analyzing Twitter user...', 'info');
        
        const response = await fetch(`/api/twitter/${username}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log('Twitter analysis response:', data);  // Debug log
        
        if (data.error) {
            showStatus(data.error, 'error');
            return;
        }

        document.getElementById('twitter-results').classList.remove('hidden');
        
        // Update sentiment chart
        updateSentimentChart(data.analyses);
        
        // Update tweets analysis
        const tweetsContainer = document.getElementById('tweets-analysis');
        tweetsContainer.innerHTML = data.analyses.map(analysis => `
            <div class="border-l-4 border-blue-500 pl-4">
                <p class="text-gray-800">${analysis.tweet}</p>
                <p class="text-sm text-gray-500 mt-1">Sentiment Score: ${analysis.sentiment_score.toFixed(2)}</p>
            </div>
        `).join('');

        showStatus('Twitter analysis completed', 'success');
    } catch (error) {
        console.error('Error analyzing Twitter user:', error);
        showStatus('Error analyzing Twitter user', 'error');
    }
}

// Token scanning
async function scanTokens() {
    try {
        showStatus('Scanning for new tokens...', 'info');
        
        const response = await fetch('/api/scan');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log('Token scan response:', data);  // Debug log

        document.getElementById('tokens-results').classList.remove('hidden');
        document.getElementById('last-scan-time').textContent = new Date().toLocaleTimeString();
        
        const tokensTable = document.getElementById('tokens-table');
        tokensTable.innerHTML = data.tokens.map(token => `
            <tr>
                <td class="px-6 py-4 whitespace-nowrap">
                    <div class="text-sm font-medium text-gray-900">${token.name}</div>
                    <div class="text-sm text-gray-500">${token.address}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <div class="text-sm text-gray-900">${token.score.toFixed(2)}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                           ${token.score >= 7 ? 'bg-green-100 text-green-800' : 
                             token.score >= 5 ? 'bg-yellow-100 text-yellow-800' : 
                             'bg-red-100 text-red-800'}">
                        ${token.score >= 7 ? 'Low Risk' : token.score >= 5 ? 'Medium Risk' : 'High Risk'}
                    </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <button onclick='showTokenDetails(${JSON.stringify(token)})' 
                            class="text-blue-600 hover:text-blue-900">
                        View Details
                    </button>
                </td>
            </tr>
        `).join('');

        showStatus('Token scan completed', 'success');
    } catch (error) {
        console.error('Error scanning tokens:', error);
        showStatus('Error scanning tokens', 'error');
    }
}

// Chart update
function updateSentimentChart(analyses) {
    const ctx = document.getElementById('sentiment-chart').getContext('2d');
    
    if (sentimentChart) {
        sentimentChart.destroy();
    }
    
    sentimentChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: analyses.map((_, i) => `Tweet ${i + 1}`),
            datasets: [{
                label: 'Sentiment Score',
                data: analyses.map(a => a.sentiment_score),
                borderColor: 'rgb(59, 130, 246)',
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 1
                }
            }
        }
    });
}

// Token details modal
function showTokenDetails(token) {
    // 实现代币详情模态框/弹出窗口
    console.log('Token details:', token);
    alert(JSON.stringify(token, null, 2));
}

// Live updates
function updateLiveUpdates(data) {
    const updatesContainer = document.getElementById('live-updates');
    const updateElement = document.createElement('div');
    updateElement.className = 'bg-gray-50 rounded-md p-4';
    updateElement.innerHTML = `
        <div class="text-sm">
            <span class="font-medium">${new Date().toLocaleTimeString()}</span>
            <p class="mt-1">${JSON.stringify(data)}</p>
        </div>
    `;
    updatesContainer.prepend(updateElement);
    
    // Keep only last 10 updates
    while (updatesContainer.children.length > 10) {
        updatesContainer.removeChild(updatesContainer.lastChild);
    }
}

// Initialize event listeners
document.addEventListener('DOMContentLoaded', () => {
    // Initialize WebSocket
    initWebSocket();
    
    // Bind button click events
    document.getElementById('analyze-twitter-btn').addEventListener('click', analyzeTwitterUser);
    document.getElementById('scan-tokens-btn').addEventListener('click', scanTokens);
    
    // Add enter key support for Twitter analysis
    document.getElementById('twitter-username').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            analyzeTwitterUser();
        }
    });
});